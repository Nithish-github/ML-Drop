export enum BlockType {
  Image_Block,
  ML_Block,
}
